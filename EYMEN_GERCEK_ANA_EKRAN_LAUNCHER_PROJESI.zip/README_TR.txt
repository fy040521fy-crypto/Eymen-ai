EYMEN LAUNCHER — ANDROID PROJESİ

Bu proje, onaylanan EYMEN ana ekranını WebView içinde gösteren gerçek bir Android HOME uygulamasıdır.
Kurulduğunda Android varsayılan ana ekran seçicisinde EYMEN olarak görünür.

APK oluşturma:
1. Bu klasörün içeriğini GitHub deposunun kök dizinine yükleyin.
2. GitHub > Actions > Build EYMEN Launcher APK iş akışını çalıştırın.
3. Tamamlandığında Actions çalışmasının Artifacts bölümünden EYMEN-Launcher-APK dosyasını indirin.
4. ZIP içinden app-debug.apk dosyasını telefona kurun.
5. Ana ekran tuşuna basın ve EYMEN'i varsayılan ana ekran olarak seçin.

Not: Bu, web kısayolu değil Android HOME uygulamasıdır. Mikrofon ilk kullanımda Android izni ister.
